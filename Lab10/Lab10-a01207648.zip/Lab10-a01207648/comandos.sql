SET DATEFORMAT dmy
BULK INSERT a1207648.a1207648.[Entregan]
   FROM 'e:\wwwroot\a1207648\entregan.csv'
   WITH
      (
		
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )

	  SELECT  * FROM Entregan

	  BULK INSERT a1207648.a1207648.[Proyectos]
   FROM 'e:\wwwroot\a1207648\proyectos.csv'
   WITH
      (
		
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )

	  BULK INSERT a1207648.a1207648.[Proveedores]
   FROM 'e:\wwwroot\a1207648\proveedores.csv'
   WITH
      (
		
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )

	  BULK INSERT a1207648.a1207648.[Materiales]
   FROM 'e:\wwwroot\a1207648\Materiales.csv'
   WITH
      (
		
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )

	  SELECT  * FROM Materiales

	  SELECT  * FROM Proveedores

	  SELECT  * FROM Proyectos

	  SELECT  * FROM Entregan

DROP TABLE Materiales
DROP TABLE Entregan
DROP TABLE Proyectos
DROP TABLE Proveedores

